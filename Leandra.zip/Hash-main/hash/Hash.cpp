#include "main.h"

int main() {
  TabelaHash();
 
}
